numpy_eigen
===========

A boost python converter that handles the copy of matrices from the Eigen linear algebra library in C++ to numpy in Python.

This is a minimal version based on the original from Paul Furgale (https://github.com/ethz-asl/Schweizer-Messer/tree/master/numpy_eigen)